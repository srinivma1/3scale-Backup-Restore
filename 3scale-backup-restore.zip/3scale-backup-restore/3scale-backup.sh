#!/bin/bash

set -e


OC_USERNAME=$1
OC_PASSWORD=$2
OC_ADDRESS=$3
BACKUP_DIR="/root/3scale_backup"
NAMESPACE_TO_BACKUP=$4
BACKUP_DIR_WITH_DATE=${BACKUP_DIR}_$(date +%Y%m%d%H%M)
DEPLOYMENT_NAME=apimanager

# Login to OCP

function oc_login() {
    
    echo " Connecting to Openshift..."
    oc login ${OC_ADDRESS} -u ${OC_USERNAME} -p ${OC_PASSWORD}> /dev/null
    
}

function datasets_backup(){

echo -n "Start of system-mysql backup"
echo
oc rsh $(oc get pods -l 'deploymentConfig=system-mysql' -o json | jq -r '.items[0].metadata.name') bash -c 'export MYSQL_PWD=${MYSQL_ROOT_PASSWORD}; mysqldump --single-transaction -hsystem-mysql -uroot system' | gzip > system-mysql-backup.gz
echo -n "system-mysql backup completed"
echo

echo -n "Start of system-app backup"
echo
oc rsync $(oc get pods -l 'deploymentConfig=system-app' -o json | jq '.items[0].metadata.name' -r):/opt/system/public/system .
echo -n "system-app backup completed"
echo

echo -n "backend-redis backup started"
echo
oc cp $(oc get pods -l 'deploymentConfig=backend-redis' -o json | jq '.items[0].metadata.name' -r):/var/lib/redis/data/dump.rdb ./backend-redis-dump.rdb
echo -n "backend-redis backup completed"
echo

echo -n "system-redis backup started"
echo
oc cp $(oc get pods -l 'deploymentConfig=system-redis' -o json | jq '.items[0].metadata.name' -r):/var/lib/redis/data/dump.rdb ./system-redis-dump.rdb
echo -n "system-redis backup completed"
echo





}

function backup_secrets(){
echo -n "secrets backup started"
echo
mkdir -p secrets

cd secrets

oc get secrets system-smtp -o json --export | jq -r 'del(.metadata.ownerReferences,.metadata.selfLink)' > system-smtp.json
oc get secrets system-seed -o json --export | jq -r 'del(.metadata.ownerReferences,.metadata.selfLink)' > system-seed.json
oc get secrets system-database -o json --export | jq -r 'del(.metadata.ownerReferences,.metadata.selfLink)' > system-database.json
oc get secrets backend-internal-api -o json --export | jq -r 'del(.metadata.ownerReferences,.metadata.selfLink)' > backend-internal-api.json
oc get secrets system-events-hook -o json --export  | jq -r 'del(.metadata.ownerReferences,.metadata.selfLink)'> system-events-hook.json
oc get secrets system-app -o json --export | jq -r 'del(.metadata.ownerReferences,.metadata.selfLink)' > system-app.json
oc get secrets system-recaptcha -o json --export | jq -r 'del(.metadata.ownerReferences,.metadata.selfLink)' > system-recaptcha.json
oc get secrets system-redis -o json --export  | jq -r 'del(.metadata.ownerReferences,.metadata.selfLink)'> system-redis.json
oc get secrets zync -o json --export | jq -r 'del(.metadata.ownerReferences,.metadata.selfLink)' > zync.json
oc get secrets system-master-apicast -o json --export | jq -r 'del(.metadata.ownerReferences,.metadata.selfLink)' > system-master-apicast.json
echo -n "Secrets backup completed"
echo
}



function backup_configmaps(){
echo -n "Configmap backup started"
echo
cd ..
mkdir -p configmap

cd configmap
oc get configmaps system-environment -o json --export | jq -r 'del(.metadata.ownerReferences,.metadata.selfLink)' > system-environment.json
oc get configmaps apicast-environment -o json --export | jq -r 'del(.metadata.ownerReferences,.metadata.selfLink)' > apicast-environment.json

cd ..
echo -n "Configmap backup completed"
echo

}

function backup_zync_database(){
echo -n "Zync database backup started"
echo
ZYNC_SPEC=`oc get APIManager/${DEPLOYMENT_NAME} -o json | jq -r '.spec.zync'`

oc patch APIManager/${DEPLOYMENT_NAME} --type merge -p '{"spec": {"zync": {"appSpec": {"replicas": 0}, "queSpec": {"replicas": 0}}}}'

sleep 10s


oc rsh $(oc get pods -l 'deploymentConfig=zync-database' -o json | jq '.items[0].metadata.name' -r) bash -c 'pg_dumpall -c --if-exists' | gzip > zync-database-backup.gz

oc patch APIManager ${DEPLOYMENT_NAME} --type merge -p '{"spec": {"zync":'"${ZYNC_SPEC}"'}}'

echo -n "Zync database backup completed"

}





# Check prerequisites 


 if [ "$#" -ne 4 ]; then
	echo "Usage: <OPENSHIFT_USERNAME> <OPENSHIFT_PASSWORD> <OPENSHIFT_ADDRESS> <NAMESPACE_TO_BACKUP>"
	   exit 1
	fi




# Connect to openshift
oc_login
#Create Backup Directory
mkdir -p $BACKUP_DIR_WITH_DATE

#Switch to the project
oc project $NAMESPACE_TO_BACKUP

cd $BACKUP_DIR_WITH_DATE

# Data Sets Backup
# This includes system-mysql, system-storage, backend-redis, system-redis
datasets_backup

# backup secrets for future restore in the secrets folder
backup_secrets

# backup configmaps for future restore in the configaps folder
backup_configmaps

# backup zync-database
backup_zync_database




