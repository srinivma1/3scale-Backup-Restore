#!/bin/bash

set -e

# OCP Credentials
OC_USERNAME=$1                                                                                                          OC_PASSWORD=$2
OC_ADDRESS=$3


BACKUP_DIR_WITH_DATE=$4
NAMESPACE_TO_RESTORE=$5
DEPLOYMENT_NAME=apimanager
CONFIGMAP_TEMPLATES_DIR="/root/templates"



# Login to OCP


function oc_login() {

	    echo " Connecting to Openshift..."
	        oc login ${OC_ADDRESS} -u ${OC_USERNAME} -p ${OC_PASSWORD}> /dev/null

	}


function restore_secrets() {

echo "Restoring Secrets..."
oc apply -f secrets/system-smtp.json
oc apply -f secrets/system-seed.json
oc apply -f secrets/system-database.json
oc apply -f secrets/backend-internal-api.json
oc apply -f secrets/system-events-hook.json
oc apply -f secrets/system-app.json
oc apply -f secrets/system-recaptcha.json
oc apply -f secrets/system-redis.json
oc apply -f secrets/zync.json
oc apply -f secrets/system-master-apicast.json

}

function restore_configmaps() {
echo "Restoring configmaps..."	
oc apply -f configmap/system-environment.json
oc apply -f configmap/apicast-environment.json

}

function restore_system_mysql() {
    
echo " Restoring system-mysql ...."
oc cp system-mysql-backup.gz $(oc get pods -l 'deploymentConfig=system-mysql' -o json | jq '.items[0].metadata.name' -r):/var/lib/mysql
oc rsh $(oc get pods -l 'deploymentConfig=system-mysql' -o json | jq -r '.items[0].metadata.name') bash -c 'gzip -f -d ${HOME}/system-mysql-backup.gz'
oc rsh $(oc get pods -l 'deploymentConfig=system-mysql' -o json | jq -r '.items[0].metadata.name') bash -c 'export MYSQL_PWD=${MYSQL_ROOT_PASSWORD}; mysql -hsystem-mysql -uroot system < ${HOME}/system-mysql-backup'
   
}

function restore_system_storage() {
    
echo -n "Restoring system storage"
echo
oc rsync system/ $(oc get pods -l 'deploymentConfig=system-app' -o json | jq '.items[0].metadata.name' -r):/opt/system/public/system
echo -n "Restoring system storage completed"
   
}

function restore_zync_database() {
    
echo -n "Restoring Zync database started"

ZYNC_SPEC=`oc get APIManager/${DEPLOYMENT_NAME} -o json | jq -r '.spec.zync'`
oc patch APIManager/${DEPLOYMENT_NAME} --type merge -p '{"spec": {"zync": {"appSpec": {"replicas": 0}, "queSpec": {"replicas": 0}}}}'

sleep 10s

oc cp zync-database-backup.gz $(oc get pods -l 'deploymentConfig=zync-database' -o json | jq '.items[0].metadata.name' -r):/var/lib/pgsql/

oc rsh $(oc get pods -l 'deploymentConfig=zync-database' -o json | jq -r '.items[0].metadata.name') bash -c 'gzip -f -d ${HOME}/zync-database-backup.gz'

oc rsh $(oc get pods -l 'deploymentConfig=zync-database' -o json | jq -r '.items[0].metadata.name') bash -c 'psql -f ${HOME}/zync-database-backup'

oc patch APIManager ${DEPLOYMENT_NAME} --type merge -p '{"spec": {"zync":'"${ZYNC_SPEC}"'}}'

echo -n "Restoring Zync database completed"
echo
   
}

function restore_backend_redis() {
    
echo -n "Restoring backend-redis started"
echo
oc apply -f ${CONFIGMAP_TEMPLATES_DIR}/redis-config-commented.json

oc rollout latest dc/backend-redis

oc rollout status dc/backend-redis

oc rsh $(oc get pods -l 'deploymentConfig=backend-redis' -o json | jq '.items[0].metadata.name' -r) bash -c 'mv ${HOME}/data/dump.rdb ${HOME}/data/dump.rdb-old'

oc rsh $(oc get pods -l 'deploymentConfig=backend-redis' -o json | jq '.items[0].metadata.name' -r) bash -c 'mv ${HOME}/data/appendonly.aof ${HOME}/data/appendonly.aof-old'

oc cp backend-redis-dump.rdb $(oc get pods -l 'deploymentConfig=backend-redis' -o json | jq '.items[0].metadata.name' -r):/var/lib/redis/data/dump.rdb

oc apply -f ${CONFIGMAP_TEMPLATES_DIR}/redis-config.json
oc rollout latest dc/backend-redis
oc rollout status dc/backend-redis
echo -n "Restoring backend-redis completed"
echo
   
}

function restore_system_redis() {
    
echo -n "Restoring system-redis database started"
echo
oc apply -f ${CONFIGMAP_TEMPLATES_DIR}/redis-config-commented.json
oc rollout latest dc/system-redis
oc rollout status dc/system-redis
oc rsh $(oc get pods -l 'deploymentConfig=system-redis' -o json | jq '.items[0].metadata.name' -r) bash -c 'mv ${HOME}/data/dump.rdb ${HOME}/data/dump.rdb-old'

oc rsh $(oc get pods -l 'deploymentConfig=system-redis' -o json | jq '.items[0].metadata.name' -r) bash -c 'mv ${HOME}/data/appendonly.aof ${HOME}/data/appendonly.aof-old'


oc cp system-redis-dump.rdb $(oc get pods -l 'deploymentConfig=system-redis' -o json | jq '.items[0].metadata.name' -r):/var/lib/redis/data/dump.rdb

oc rollout latest dc/system-redis

oc rollout status dc/system-redis

oc apply -f ${CONFIGMAP_TEMPLATES_DIR}/redis-config.json
oc rollout latest dc/system-redis

oc rollout status dc/system-redis

echo -n "Restoring system-redis database completed"
echo
   
}
function finalize() {
    
echo -n "Rolling out the latest backend-worker deployment"
echo
oc rollout latest dc/backend-worker

oc rollout status dc/backend-worker
echo -n "Rolling out the latest system-app deployment"
echo

oc rollout latest dc/system-app

oc rollout status dc/system-app

echo "Resync domains"

oc exec -t $(oc get pods -l 'deploymentConfig=system-sidekiq' -o json | jq '.items[0].metadata.name' -r) -- bash -c "bundle exec rake zync:resync:domains"

   
}



# Check prerequisites 

 if [ "$#" -ne 5 ]; then
	echo "Usage: <OPENSHIFT_USERNAME>  <OPENSHIFT_PASSWORD> <OPENSHIFT_ADDRESS> <BACKUP_DIR_WITH_DATE> <NAMESPACE_TO_RESTORE>"
	   exit 1
	fi




# Connect to openshift
oc_login
cd $BACKUP_DIR_WITH_DATE

#Switch to the project 
oc project $NAMESPACE_TO_RESTORE

# Restore secrets before creating APIManager resource.
restore_secrets

# Restore secrets before creating APIManager resource.
restore_configmaps

# Restore system-mysql
restore_system_mysql

# restore system storage
restore_system_storage

# restore_zync_database
restore_zync_database

# restore backend_redis
restore_backend_redis

# restore_system_redis
restore_system_redis

#finalize
finalize






